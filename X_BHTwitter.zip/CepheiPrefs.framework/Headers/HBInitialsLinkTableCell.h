#import "HBLinkTableCell.h"

/// The HBInitialsLinkTableCell class in CepheiPrefs is a shim kept for compatibility reasons.
/// The class is now called `HBLinkTableCell`.

@interface HBInitialsLinkTableCell : HBLinkTableCell

@end
