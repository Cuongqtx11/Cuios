#import <Preferences/PSSpecifier.h>
#import <Preferences/PSEditableTableCell.h>
#import "../HUtilities/HCommon.h"
#import "HPSRootListController.h"

@interface HPSEditTextCell : PSEditableTableCell
@end
